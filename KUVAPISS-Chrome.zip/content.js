(() => {
  "use strict";

  // Accepte aussi les espaces insécables et le ñ décomposé (n + tilde).
  const pattern = /Laurent\s+Nu(?:n\u0303?|ñ)e[zs]/giu;
  const replacement = "Grosse cuve à pisse";
  const excluded =
    'script, style, noscript, textarea, input, [contenteditable="true" i], ' +
    '[contenteditable=""], [contenteditable="plaintext-only" i]';

  function isExcluded(node) {
    const element = node.nodeType === Node.ELEMENT_NODE
      ? node
      : node.parentElement;
    return Boolean(element && element.closest(excluded));
  }

  function replaceText(node) {
    if (isExcluded(node)) return;
    const previous = node.nodeValue;
    const next = previous.replace(pattern, replacement);
    if (next !== previous) node.nodeValue = next;
  }

  function scan(root) {
    if (!root.isConnected || isExcluded(root)) return;
    if (root.nodeType === Node.TEXT_NODE) {
      replaceText(root);
      return;
    }

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        return isExcluded(node)
          ? NodeFilter.FILTER_REJECT
          : NodeFilter.FILTER_ACCEPT;
      }
    });
    let node;
    while ((node = walker.nextNode())) replaceText(node);
  }

  const options = { childList: true, subtree: true, characterData: true };
  const observer = new MutationObserver((records) => {
    const roots = new Set();
    for (const record of records) {
      if (record.type === "characterData") roots.add(record.target);
      else for (const node of record.addedNodes) roots.add(node);
    }

    // Les mutations du site sont déjà recueillies. Nos écritures synchrones
    // ne doivent pas déclencher une nouvelle livraison de l'observateur.
    observer.disconnect();
    try {
      for (const root of roots) {
        // Évite de parcourir deux fois un sous-arbre ajouté avec son parent.
        let parent = root.parentNode;
        while (parent && !roots.has(parent)) parent = parent.parentNode;
        if (!parent) scan(root);
      }
    } finally {
      observer.observe(document, options);
    }
  });

  scan(document);
  observer.observe(document, options);
})();
